﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private RSAencryption rsa = new RSAencryption();
        private asci asci = new asci();
        List<encryption> listofEncryptions = new List<encryption>();
        public MainWindow()
        {
            InitializeComponent();
            listofEncryptions.Add(rsa);
            listofEncryptions.Add(asci);
        }
        private void generateClick(object sender, RoutedEventArgs e)
        {
            try
            {
                rsa.generateKeys();
                publicTextBox.Text = rsa.PublicKey;
                privateTextBox.Text = rsa.PrivateKey;
            }
            catch
            {
                MessageBox.Show("Error.");
            }
        }
        private void encryptClick(object sender, RoutedEventArgs e)
        {
            if(RSA.IsChecked == true) { 
                try
                {
                    rsa.UnencryptedText = unencryptedTextBox.Text;
                    rsa.PublicKey = publicTextBox.Text;
                    rsa.encryptText();
                    //to meet requirments and demonstrate LINQ
                    var query = from p in listofEncryptions where p.GetType() == typeof(RSAencryption) select p;
                    foreach(var key in query) { 
                        encryptedTextBox.Text = key.EncryptedText;
                    }
                }
                catch
                {
                    MessageBox.Show("Error.");
                }
            }
            if(ascibutton.IsChecked == true)
            {
                try
                {
                    asci.UnencryptedText = unencryptedTextBox.Text;
                    asci.encryptText();
                    var query = from p in listofEncryptions where p.GetType() == typeof(asci) select p;
                    foreach (var key in query)
                    {
                        encryptedTextBox.Text = key.EncryptedText;
                    }
                }
                catch
                {
                    MessageBox.Show("Error. ");
                }
            }
        }

        private void decryptClick(object sender, RoutedEventArgs e)
        {
            if (RSA.IsChecked == true)
            {
                try
                {
                    rsa.EncryptedText = encryptedTextBox.Text;
                    rsa.PrivateKey = privateTextBox.Text;
                    rsa.decryptText();
                    //to meet requirments and demonstrate LINQ
                    var query = from p in listofEncryptions where p.GetType() == typeof(RSAencryption) select p;
                    foreach (var key in query) { 
                        unencryptedTextBox.Text = key.UnencryptedText;
                    }
                }
                catch
                {
                    MessageBox.Show("Error.");
                }
            }
            if(ascibutton.IsChecked== true)
            {
                try
                {
                    asci.EncryptedText=encryptedTextBox.Text;
                    asci.decryptText();
                    var query = from p in listofEncryptions where p.GetType() == typeof(asci) select p;
                    foreach (var key in query)
                    {
                        unencryptedTextBox.Text = key.UnencryptedText;
                    }
                }
                catch
                {
                    MessageBox.Show("Error.");
                }
            }
        }
    }
}
