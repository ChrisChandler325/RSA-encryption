﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class encryption
    {
        protected string unencryptedText;
        protected string encryptedText;
        public encryption() { }

        public string UnencryptedText { get { return unencryptedText; } set { unencryptedText = value; } }
        public string EncryptedText { get { return encryptedText; } set { encryptedText = value; } }

        public virtual void encryptText()
        {

        }
        public virtual void decryptText()
        {

        }

    }
}
