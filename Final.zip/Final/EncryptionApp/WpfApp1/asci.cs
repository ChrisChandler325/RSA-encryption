﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class asci : encryption
    {
        public override void encryptText()
        {
            this.encryptedText = string.Join(" ", this.unencryptedText.Select(c => Convert.ToInt32(c)));       
        }
        public override void decryptText()
        {
            //using loops for credit
            List<int> list = new List<int>();
            //converting string to list of ascii ints
            foreach (var c in this.encryptedText.Split(' '))
            {
                list.Add(Convert.ToInt32(c));
            }
            string k = "";
            //converting ascii ints to char into a string
            foreach (var c in list)
            {
                k += char.ConvertFromUtf32(c);
            }
            this.UnencryptedText = k;
        }
    }
}
