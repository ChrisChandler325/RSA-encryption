﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    //Here are the references I used:
    //https://www.devglan.com/online-tools/rsa-encryption-decryption
    //https://learn.microsoft.com/en-us/dotnet/api/system.text.utf8encoding.getstring?view=net-8.0
    //https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.rsacryptoserviceprovider?view=net-8.0
    //https://www.codeproject.com/Questions/218448/Generate-public-private-key-pair-and-show-them-in
    internal class RSAencryption : encryption
    {
        private string publicKeyLoad;
        private string privateKeyLoad;
        //private string unencryptedText;
        //private string encryptedText;
        public RSAencryption() { }        

        public string PublicKey { get { return publicKeyLoad; } set { publicKeyLoad = value; } }
        public string PrivateKey { get { return privateKeyLoad; } set { privateKeyLoad = value; } }
        //public string UnencryptedText { get { return unencryptedText; } set { unencryptedText = value; } }
        //public string EncryptedText { get { return encryptedText; } set { encryptedText = value; } }

        public void generateKeys()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);
            this.PrivateKey = rsa.ToXmlString(true);
            this.PublicKey = rsa.ToXmlString(false);
        }
        public override void encryptText()
        {
            byte[] data = Encoding.UTF8.GetBytes(this.unencryptedText);
            this.encryptedText = Convert.ToBase64String(encryptOaepSha1(this.PublicKey,data));
        }
        private byte[] encryptOaepSha1(string publicKey, byte[] data)
        {
            RSACryptoServiceProvider padding = new RSACryptoServiceProvider(2048);
            padding.PersistKeyInCsp = false;
            padding.FromXmlString(publicKey);
            return padding.Encrypt(data, true);
        }
        public override void decryptText()
        {
            byte[] data = Convert.FromBase64String(this.encryptedText);
            byte[] text = decryptOaepSha1(this.PrivateKey, data);
            this.unencryptedText = Encoding.UTF8.GetString(text);
        }
        private byte[] decryptOaepSha1(string privateKey, byte[] data)
        {
            RSACryptoServiceProvider unpad = new RSACryptoServiceProvider(2048);
            unpad.PersistKeyInCsp = false;
            unpad.FromXmlString(privateKey);
            return unpad.Decrypt(data, true);
        }
    }
}
